### Podcasty

* [Brus kódu](http://bruskodu.cz) - pro frontend vývojáře
* [CZpodcast](http://java.cz/article/czpodcast)
* [DevMinutes](http://devminutes.cz)
* [Kafemlejnek.TV](https://kafemlejnek.tv)
