### Index

* [Databases](#databases)
* [iOS](#ios)
* [Language Agnostic](#language-agnostic)


### Databases

* [Podcast] - [DatabaseCast](http://databasecast.com.br)


### iOS

* [Podcast] - [CocoaHeads](http://www.cocoaheads.com.br/podcasts)


### Language Agnostic

 * [Podcast] - [Castálio Podcast](http://castalio.info)
 * [Podcast] - [DevNaEstrada](http://devnaestrada.com.br)
 * [Podcast] - [Grok Podcast](http://www.grokpodcast.com)
 * [Podcast] - [Hipsters Ponto Tech](http://hipsters.tech)
 * [Podcast] - [Lambda3](https://blog.lambda3.com.br/category/podcast)
 * [Podcast] - [NerdTech](https://jovemnerd.com.br/playlist/nerdtech)
 * [Podcast] - [PODebug](http://www.podebug.com)
 * [Podcast] - [PodProgramar](https://mundopodcast.com.br/podprogramar)
