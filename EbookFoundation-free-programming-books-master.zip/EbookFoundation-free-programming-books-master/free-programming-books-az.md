### Index

* [C](#c)
* [CSS](#css)
* [HTML](#html)
* [JavaScript](#javascript)
* [Linux](#Linux)
* [PHP](#php)


### C

* [C Proqramlaşdırma Dilinə Giriş](http://ilkaddimlar.com/C-Proqramlasdirma-dili/428/Giris)


### CSS

* [CSS](http://ilkaddimlar.com/kateqoriya12/CSS)


### HTML

* [HTML](http://ilkaddimlar.com/HTML/36/Esas-aletler-El-ile-islemeyi-oyrenirik)


### JavaScript

* [JavaScript Garden](http://ilkaddimlar.com/JavaScript/182/Obyekt-anlayisi)


### Linux

* [Linux](http://ilkaddimlar.com/Linux/Linux/18/Linux)


### PHP

* [PHP](http://ilkaddimlar.com/PHP/PHP/17/PHP)
