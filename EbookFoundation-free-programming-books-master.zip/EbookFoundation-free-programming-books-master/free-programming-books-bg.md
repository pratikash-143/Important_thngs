### Index

* [C](#c)
* [C#](#c-sharp)
* [Java](#java)
* [LaTeX](#latex)


### C

* [Програмиране = ++ Алгоритми](http://www.programirane.org/2013/02/free-download-algo-book-nakov-dobrikov/) - Преслав Наков и Панайот Добриков


### C Sharp

* [Въведение в програмирането със С#](http://www.introprogramming.info/wp-content/uploads/2011/07/Intro-CSharp-Book-1.00.pdf) -  Светлин Наков, Веселин Колев и колектив (PDF)
* [Програмиране за .NET Framework](http://www.devbg.org/dotnetbook/) - Светлин Наков и колектив


### Java

* [Въведение в програмирането с Java](http://www.introprogramming.info/intro-java-book/read-online/) - Светлин Наков
* [Интернет програмиране с Java](http://www.nakov.com/books/inetjava/index.html) - Светлин Наков


### LaTeX

* [Кратко въведение в LaTeX2ε](http://www.ctan.org/tex-archive/info/lshort/bulgarian) - Стефка Караколева
