### Index

* [C](#c)
* [C++](#c-1)
* [JavaScript](#javascript)
* [PHP](#php)
* [Python](#python)
* [Ruby](#ruby)


### C

* [C](https://fi.wikibooks.org/wiki/C)
* [C-ohjelmointi](http://www.ohjelmointiputka.net/oppaat/opas.php?tunnus=c_esittaja)


### C++

* [C++](https://fi.wikibooks.org/wiki/C%2B%2B)


### JavaScript

* [JavaScript](https://fi.wikibooks.org/wiki/JavaScript)


### PHP

* [PHP](https://fi.wikibooks.org/wiki/PHP)
* [PHP-ohjelmointi](http://www.ohjelmointiputka.net/oppaat/opas.php?tunnus=php_01)


### Python

* [Python 2](https://fi.wikibooks.org/wiki/Python_2)
* [Python 3](https://fi.wikibooks.org/wiki/Python_3)
* [Python-ohjelmointi](http://www.ohjelmointiputka.net/oppaat/opas.php?tunnus=python3_01)


### Ruby

* [Ruby](https://fi.wikibooks.org/wiki/Ruby)
