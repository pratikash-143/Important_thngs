### Index

* [Ajax](#ajax)
* [HTML](#hmtl)
* [MySQL](#mysql)
* [PHP](#php)


### Ajax

* [Ajax](http://etutoriale.ro/articles/1483/1/Tutorial-Ajax/)


### HMTL

* [HTML](http://tutorialehtml.com/ro/introducere-in-html/)


### MySQL

* [MySQL](http://profs.info.uaic.ro/~busaco/teach/courses/net/docs/mysql-ro.pdf) (PDF)


### PHP

* [PHP](http://php.punctsivirgula.ro)
