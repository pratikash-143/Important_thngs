### ClojureScript

* [Розплутаний ClojureScript](https://lambdabooks.github.io/clojurescript-unraveled) — Роман Лютіков (LambdaBooks)


### Index

* [Haskell](#haskell)
* [Java](#java)
* [Language Agnostic](#language-agnostic)
* [Python](#python)
* [Ruby](#ruby)


### Haskell

* [Вивчить собі Хаскела на велике щастя!](http://haskell.trygub.com) - Міран Ліповача


### Java

* [Програмування мовою Java для дітей, батьків, дідусів та бабусь](http://myflex.org/books/java4kids/java4kids.htm) - Яків Файн


### JavaScript

* [Розуміння ECMAScript 6](http://understandinges6.denysdovhan.com) — Денис Довгань (LambdaBooks)


### Language Agnostic

* [Дизайн патерни - просто, як двері](http://designpatterns.andriybuday.com) - А. Будай


### Python

* [Пориньте у Python 3](https://uk.wikibooks.org/wiki/Пориньте_у_Python_3) - Марк Пілігрим


### Ruby

* [Маленька книга про Ruby](https://lambdabooks.github.io/thelittlebookofruby) — Сергій Гіба (LambdaBooks)
