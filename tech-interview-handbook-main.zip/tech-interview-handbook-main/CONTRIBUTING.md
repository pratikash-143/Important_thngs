## Contributing

When contributing to this repository, if it is a non-trivial change, please first discuss the change you wish to make via creating an issue in this repository.

As much as possible, try to follow the existing format of markdown and code. JavaScript code should adopt [Standard style](https://standardjs.com/).

Please note we have a Code of Conduct, please follow it in all your interactions with the project.
