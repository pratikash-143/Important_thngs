-- AlterEnum
ALTER TYPE "QuestionsQuestionType" ADD VALUE 'THEORY';
