-- AlterTable
ALTER TABLE "Company" ADD COLUMN     "website" TEXT;
