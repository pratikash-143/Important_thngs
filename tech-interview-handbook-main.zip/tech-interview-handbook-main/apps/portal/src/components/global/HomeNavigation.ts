// Not using this for now.
// const navigation: ProductNavigationItems = [
//   { href: '/offers', name: 'Offers' },
//   { href: '/questions', name: 'Question Bank' },
//   {
//     children: [
//       { href: '/resumes', name: 'View Resumes' },
//       { href: '/resumes/submit', name: 'Submit Resume' },
//     ],
//     href: '#',
//     name: 'Resumes',
//   },
// ];

const config = {
  navigation: [],
  showGlobalNav: false,
  title: 'Tech Interview Handbook',
  titleHref: '/',
};

export default config;
