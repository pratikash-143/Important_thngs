export const RESUME_STORAGE_KEY = 'resumes';
