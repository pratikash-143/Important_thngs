import React from 'react';
import type { Props } from '@theme/DocSidebar/Mobile';
declare function DocSidebarMobile(props: Props): JSX.Element;
declare const _default: React.MemoExoticComponent<typeof DocSidebarMobile>;
export default _default;
